import { createContext, useContext, useEffect, useMemo, useState } from 'react'
import * as db from '../lib/storage'

const AppContext = createContext(null)

export function AppProvider({ children }) {
  const [usuario, setUsuario] = useState(() => db.usuarioDaSessao())
  const [dados, setDados] = useState(() =>
    usuario ? db.carregarDados(usuario.id) : { metas: [], historico: [] },
  )

  useEffect(() => {
    if (usuario) db.salvarDados(usuario.id, dados)
  }, [usuario, dados])

  // ───────────────────────────── autenticação ─────────────────────────────

  function entrar({ email, senha }) {
    const { usuario: u, erro } = db.autenticar({ email, senha })
    if (erro) return { erro }
    db.salvarSessao(u.id)
    setUsuario(u)
    setDados(db.carregarDados(u.id))
    return { usuario: u }
  }

  function cadastrar({ nome, email, senha, provedor }) {
    const { usuario: u, erro } = db.criarUsuario({ nome, email, senha, provedor })
    if (erro) return { erro }
    db.salvarSessao(u.id)
    setUsuario(u)
    setDados(db.carregarDados(u.id))
    return { usuario: u }
  }

  /** Login social simulado: entra se a conta existe, cadastra se não existe. */
  function entrarComProvedor(provedor) {
    const slug = provedor.toLowerCase()
    const email = `aluno.${slug}@exemplo.com`
    const existente = db.listarUsuarios().find((u) => u.email === email)
    if (existente) {
      db.salvarSessao(existente.id)
      setUsuario(existente)
      setDados(db.carregarDados(existente.id))
      return { usuario: existente }
    }
    return cadastrar({
      nome: `Aluno ${provedor}`,
      email,
      senha: null,
      provedor: slug,
    })
  }

  function sair() {
    db.limparSessao()
    setUsuario(null)
    setDados({ metas: [], historico: [] })
  }

  function salvarPerfil(perfil) {
    const atualizado = db.atualizarUsuario(usuario.id, { perfil, perfilCompleto: true })
    setUsuario(atualizado)
    return atualizado
  }

  // ──────────────────────────────── metas ────────────────────────────────

  function adicionarMeta(meta) {
    const nova = {
      id: `m_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      criadaEm: new Date().toISOString(),
      atual: 0,
      ...meta,
    }
    setDados((d) => ({ ...d, metas: [nova, ...d.metas] }))
    return nova
  }

  function atualizarMeta(id, patch) {
    setDados((d) => ({
      ...d,
      metas: d.metas.map((m) => (m.id === id ? { ...m, ...patch } : m)),
    }))
  }

  function removerMeta(id) {
    setDados((d) => ({ ...d, metas: d.metas.filter((m) => m.id !== id) }))
  }

  function registrarProgresso(id, delta) {
    setDados((d) => ({
      ...d,
      metas: d.metas.map((m) =>
        m.id === id
          ? { ...m, atual: Math.max(0, Math.min(m.alvo, Number((m.atual + delta).toFixed(2)))) }
          : m,
      ),
    }))
  }

  // ────────────────────────── histórico de treinos ──────────────────────────

  function salvarTreino(sessao) {
    setDados((d) => ({
      ...d,
      historico: [{ id: `t_${Date.now()}`, ...sessao }, ...d.historico].slice(0, 30),
    }))
  }

  const valor = useMemo(
    () => ({
      usuario,
      metas: dados.metas,
      historico: dados.historico,
      entrar,
      cadastrar,
      entrarComProvedor,
      sair,
      salvarPerfil,
      adicionarMeta,
      atualizarMeta,
      removerMeta,
      registrarProgresso,
      salvarTreino,
    }),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [usuario, dados],
  )

  return <AppContext.Provider value={valor}>{children}</AppContext.Provider>
}

export function useApp() {
  const ctx = useContext(AppContext)
  if (!ctx) throw new Error('useApp precisa estar dentro de <AppProvider>')
  return ctx
}
